using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
   
    private int myInteger = 5;

    private void Start()
    {
        Debug.Log("My integer variable is: " + myInteger);
    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
