using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cube : MonoBehaviour
{
     private string firstName = "My name is ";
    private string lastName = "Mosammed Uddin";

    private void Start()
    {
        Debug.Log(firstName + lastName);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
