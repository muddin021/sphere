using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cylinder : MonoBehaviour
{
     private bool myBoolean = true;

    private void Start()
    {
        Debug.Log("My boolean variable is: " + myBoolean);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
